The scripts in this directory take care of basic funcionalities like the HUD, the character switching, etc.
