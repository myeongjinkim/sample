The scripts in this folder are the "player companions": they enhance the abilities of the characters.
